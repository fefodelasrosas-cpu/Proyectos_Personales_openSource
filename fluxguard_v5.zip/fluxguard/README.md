# FluxGuard — Sistema de Mitigación Inteligente (DDoS + Phishing)

Proyecto de grado · Ingeniería de Sistemas · Universidad Ean
Detección de phishing (Random Forest sobre texto + estructura de URL) y de
ataques DDoS (Isolation Forest + capa experta de reglas).

## Estructura del proyecto

```
fluxguard/
├── config.py        # Parámetros, umbrales y rutas (un solo lugar)
├── data.py          # Datasets: corpus de phishing y tráfico de red etiquetado
├── engine.py        # Motor de ML (independiente de la web; testeable aislado)
├── app.py           # Capa web Flask (valida → delega en el motor → responde)
├── evaluate.py      # Genera métricas + matrices de confusión (Tabla 4 / Fig 2)
├── templates/
│   └── index.html   # Dashboard (seguro, responsive, accesible)
├── outputs/         # Métricas CSV y PNG generados por evaluate.py
└── requirements.txt
```

Separación por capas: **datos → inteligencia → web**. El motor no sabe nada de
Flask; la web no sabe nada de scikit-learn. Eso permite testear y reemplazar
cada parte por separado.

## Instalación

```bash
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Ejecutar el dashboard

```bash
python app.py
```
Abre automáticamente http://127.0.0.1:5000

## Generar las métricas del documento (Tabla 4 y Figura 2)

```bash
python evaluate.py
```
Produce en `outputs/`:
- `metricas.csv` — exactitud, precisión, recall, F1 y latencia por modelo.
- `cm_ddos_rf.png`, `cm_ddos_dt.png`, `cm_ddos_if.png`, `cm_phishing_rf.png`
  — matrices de confusión listas para insertar en la Figura 2.

### Usar el dataset real CICDDoS2019
Coloca el CSV en `data/cicddos2019.csv` (o exporta la variable de entorno
`CICDDOS_CSV=ruta.csv`) y vuelve a ejecutar `evaluate.py`. El pipeline recalcula
todo sobre datos reales sin cambiar el código. **Las cifras oficiales del
documento deben provenir de esa ejecución.**

## Decisiones técnicas (para la sustentación)

- **Phishing = híbrido texto + URL.** TF-IDF captura la semántica de urgencia;
  las features estructurales de URL (IP embebida, `@`, TLD sospechoso, longitud,
  dígitos) capturan la manipulación del enlace. Ambos se combinan y clasifican
  con Random Forest.
- **DDoS = no supervisado + reglas.** Isolation Forest detecta la anomalía sin
  necesidad de firmas (útil ante botnets nuevas); la capa experta clasifica el
  *tipo* (volumétrico / protocolo / aplicación). Híbrido detección + categorización.
- **Bajo consumo.** Modelos ligeros (entrenan en < 1 s); apto para hardware
  limitado (incluso Raspberry Pi, como plantea el documento).
- **Seguridad de la propia herramienta.** La API valida tipos/rangos y la
  interfaz construye el DOM con `textContent` (inmune a XSS por construcción).

## Limitaciones honestas

- El corpus de phishing incluido es **demostrativo**; para producción debe
  reemplazarse por un dataset etiquetado de mayor tamaño.
- El benchmark de tráfico es **sintético con ruido realista**; las métricas
  oficiales deben calcularse sobre CICDDoS2019.
- La mitigación (rate limiting / integración con firewalls) está modelada a
  nivel de prototipo; su despliegue real requiere integración con `iptables`/
  Mikrotik/Cisco según describe el documento.
