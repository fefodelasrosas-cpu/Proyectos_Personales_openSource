"""
engine.py — Motor de inteligencia de FluxGuard.

Combina:
  - PHISHING: TF-IDF (semántica) + características estructurales de URL,
              clasificadas con Random Forest.  (supervisado)
  - DDoS:     Isolation Forest sobre tráfico normal -> detecta anomalías,
              y una capa experta de reglas clasifica el TIPO de ataque. (no supervisado)

El motor es independiente de Flask: se puede importar y probar de forma aislada.
"""
import time
import logging

import numpy as np
from scipy.sparse import hstack, csr_matrix
from sklearn.ensemble import RandomForestClassifier, IsolationForest
from sklearn.feature_extraction.text import TfidfVectorizer

import config
import data

log = logging.getLogger("fluxguard.engine")


class FluxGuard:
    def __init__(self):
        self._entrenar()

    # ---------------------------------------------------------------- PHISHING
    def _entrenar(self):
        t0 = time.perf_counter()

        # --- Phishing: TF-IDF + features de URL ---
        df = data.cargar_phishing()
        self.vectorizer = TfidfVectorizer(max_features=config.TFIDF_MAX_FEATURES)
        X_text = self.vectorizer.fit_transform(df["texto"] + " " + df["url"])
        X_url = csr_matrix(df[data.FEATURE_COLS].to_numpy(dtype=float))
        X = hstack([X_text, X_url]).tocsr()
        self.rf_phishing = RandomForestClassifier(
            n_estimators=config.RF_TREES, random_state=config.SEED, class_weight="balanced"
        )
        self.rf_phishing.fit(X, df["label"])

        # --- DDoS: Isolation Forest entrenado SOLO con tráfico normal ---
        traf, fuente = data.cargar_ddos()
        normal = traf[traf["label"] == 0][data.DDOS_FEATURES].to_numpy()
        self.if_ddos = IsolationForest(
            n_estimators=config.IF_TREES, contamination=config.IF_CONTAMINATION,
            random_state=config.SEED,
        )
        self.if_ddos.fit(normal)

        log.info("Motor entrenado en %.3fs (phishing: %d | DDoS: %s, %d normales)",
                 time.perf_counter() - t0, len(df), fuente, len(normal))

    def _features_phishing(self, texto: str, url: str):
        X_text = self.vectorizer.transform([f"{texto} {url}"])
        feats = data.extraer_features_url(texto, url)
        X_url = csr_matrix(np.array([[feats[c] for c in data.FEATURE_COLS]], dtype=float))
        return hstack([X_text, X_url]).tocsr()

    def analizar_phishing(self, texto: str, url: str = "") -> dict:
        proba = float(self.rf_phishing.predict_proba(self._features_phishing(texto, url))[0][1])
        if proba >= 0.5:
            return {"estado": "peligro", "confianza": round(proba * 100, 1),
                    "mensaje": "Intento de phishing detectado. Se recomienda bloquear remitente/URL."}
        return {"estado": "seguro", "confianza": round((1 - proba) * 100, 1),
                "mensaje": "Correo sin indicadores de phishing."}

    # ------------------------------------------------------------------- DDoS
    def _clasificar_tipo(self, pps, latencia, bw) -> str:
        if bw > config.TH_BW_VOLUMETRIC:
            return "Volumetrico (UDP/ICMP Flood)"
        if pps > config.TH_PPS_PROTOCOL:
            return "De Protocolo (SYN Flood)"
        if latencia > config.TH_LAT_APP and bw < config.TH_BW_APP:
            return "Capa de Aplicacion (Slowloris / Low & Slow)"
        return "Patron Mixto"

    def analizar_ddos(self, pps, latencia, bw, ip, syn_ratio=0.1) -> dict:
        inicio = time.perf_counter()
        vector = [[pps, latencia, bw, syn_ratio]]
        es_anomalia = self.if_ddos.predict(vector)[0] == -1
        tiempo = round(time.perf_counter() - inicio, 4)

        if not es_anomalia:
            return {"estado": "seguro", "ip": ip, "pps": pps,
                    "mensaje": "Trafico dentro de parametros normales."}

        tipo = self._clasificar_tipo(pps, latencia, bw)
        log.warning("Anomalia DDoS desde %s | tipo=%s | pps=%s", ip, tipo, pps)
        return {"estado": "peligro", "tipo": tipo, "ip": ip, "tiempo": tiempo,
                "datos": {"pps": pps, "bw": bw, "latencia": latencia}}
