"""
app.py — Capa web de FluxGuard (Flask).

Rutas disponibles:
  GET  /                    → Dashboard principal
  POST /api/phishing        → Análisis de correo
  POST /api/ddos            → Evaluación de tráfico
  GET  /api/metricas        → Métricas del modelo en JSON (para las gráficas)
  GET  /outputs/<filename>  → Sirve las imágenes PNG de matrices de confusión

Ejecutar:  python app.py
"""
import os
import time
import logging
import threading
import webbrowser
import subprocess
import sys
from html import escape

from flask import Flask, request, jsonify, render_template, send_from_directory, Response

import config
from engine import FluxGuard
from txt_report import generar_txt

# Configuro el log para ver en consola qué está pasando en cada petición
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-7s | %(message)s",
    datefmt="%H:%M:%S"
)
log = logging.getLogger("fluxguard.app")

app = Flask(__name__)

# Arranco el motor de ML al iniciar (entrena los modelos en memoria)
sistema = FluxGuard()

# Al iniciar, regenero las métricas y los PNGs automáticamente
# así el usuario siempre tiene gráficas actualizadas sin ejecutar evaluate.py a mano
def _regenerar_metricas():
    """
    Ejecuto evaluate.py en background para generar los PNGs de matrices
    y el CSV con las métricas. Lo hago en un hilo separado para no
    bloquear el arranque de Flask.
    """
    try:
        base = os.path.dirname(os.path.abspath(__file__))
        eval_path = os.path.join(base, "evaluate.py")
        result = subprocess.run(
            [sys.executable, eval_path],
            capture_output=True, text=True, timeout=60
        )
        if result.returncode == 0:
            log.info("Métricas regeneradas correctamente al iniciar.")
        else:
            log.warning("evaluate.py terminó con errores: %s", result.stderr[:200])
    except Exception as e:
        log.warning("No se pudieron regenerar las métricas: %s", e)


# ── Validadores de entrada ────────────────────────────────────────────────
def _num(payload, clave, rango):
    """Valida que un campo sea numérico y esté dentro del rango permitido."""
    if clave not in payload:
        raise ValueError(f"Falta el campo '{clave}'.")
    try:
        valor = float(payload[clave])
    except (TypeError, ValueError):
        raise ValueError(f"El campo '{clave}' debe ser numérico.")
    import math
    if not math.isfinite(valor) or not (rango[0] <= valor <= rango[1]):
        raise ValueError(f"El campo '{clave}' está fuera de rango {rango}.")
    return valor


def _texto(payload, clave, max_len):
    """Valida que un campo de texto no esté vacío y lo trunca si es muy largo."""
    valor = payload.get(clave)
    if not isinstance(valor, str) or not valor.strip():
        raise ValueError(f"El campo '{clave}' es obligatorio.")
    return valor.strip()[:max_len]


# ── Rutas principales ─────────────────────────────────────────────────────

@app.route("/")
def home():
    """Sirve el dashboard principal."""
    return render_template("index.html")


@app.route("/api/phishing", methods=["POST"])
def api_phishing():
    """Recibe texto + URL, los valida y los manda al motor de ML."""
    data = request.get_json(silent=True) or {}
    try:
        texto = _texto(data, "texto", config.MAX_TEXT_LEN)
        url   = (data.get("url") or "").strip()[:config.MAX_TEXT_LEN]
    except ValueError as err:
        return jsonify(error=str(err)), 400
    return jsonify(sistema.analizar_phishing(texto, url))


@app.route("/api/ddos", methods=["POST"])
def api_ddos():
    """Recibe métricas de red, las valida y las manda al motor de ML."""
    data = request.get_json(silent=True) or {}
    try:
        pps      = _num(data, "pps",      config.PPS_RANGE)
        latencia = _num(data, "latencia", config.LAT_RANGE)
        bw       = _num(data, "bw",       config.BW_RANGE)
        ip       = escape(_texto(data, "ip", config.IP_MAX_LEN))
    except ValueError as err:
        return jsonify(error=str(err)), 400
    return jsonify(sistema.analizar_ddos(pps, latencia, bw, ip))


@app.route("/api/metricas")
def api_metricas():
    """
    Devuelve las métricas del modelo en JSON para que el frontend
    las use en las gráficas de la pestaña Métricas del Modelo.
    Lee el CSV generado por evaluate.py si existe; si no, devuelve
    los valores conocidos del documento.
    """
    csv_path = os.path.join(config.OUTPUT_DIR, "metricas.csv")

    # Intento leer el CSV real generado por evaluate.py
    if os.path.exists(csv_path):
        try:
            import pandas as pd
            df = pd.read_csv(csv_path, index_col=0)
            modelos = []
            for nombre, row in df.iterrows():
                modelos.append({
                    "nombre":    nombre,
                    "exactitud": float(row.get("Exactitud",  0)),
                    "precision": float(row.get("Precision",  0)),
                    "recall":    float(row.get("Recall",     0)),
                    "f1":        float(row.get("F1",         0)),
                    "latencia":  float(row.get("Latencia_ms",0)),
                })
            # Le agrego qué imágenes de matriz de confusión corresponden a cada modelo
            img_map = {
                "Random Forest":           "cm_ddos_rf.png",
                "Decision Tree":           "cm_ddos_dt.png",
                "Isolation Forest":        "cm_ddos_if.png",
                "Random Forest (Phishing)":"cm_phishing_rf.png",
            }
            for m in modelos:
                m["imagen"] = img_map.get(m["nombre"], "")
            return jsonify({"fuente": "csv", "modelos": modelos})
        except Exception as e:
            log.warning("No pude leer metricas.csv: %s", e)

    # Fallback: valores del documento si no existe el CSV
    fallback = [
        {"nombre":"Random Forest",          "exactitud":97.00,"precision":96.48,"recall":96.91,"f1":96.69,"latencia":0.013,"imagen":"cm_ddos_rf.png"},
        {"nombre":"Decision Tree",          "exactitud":96.33,"precision":95.75,"recall":96.17,"f1":95.96,"latencia":0.000,"imagen":"cm_ddos_dt.png"},
        {"nombre":"Isolation Forest",       "exactitud":93.07,"precision":88.49,"recall":97.35,"f1":92.71,"latencia":0.010,"imagen":"cm_ddos_if.png"},
        {"nombre":"Random Forest (Phishing)","exactitud":100.0,"precision":100.0,"recall":100.0,"f1":100.0,"latencia":0.254,"imagen":"cm_phishing_rf.png"},
    ]
    return jsonify({"fuente": "fallback", "modelos": fallback})


@app.route("/outputs/<path:filename>")
def serve_output(filename):
    """
    Sirve los archivos de la carpeta outputs/ (PNGs de matrices de confusión).
    Sin esta ruta, el navegador no puede cargar las imágenes.
    """
    return send_from_directory(config.OUTPUT_DIR, filename)


@app.route("/api/reporte", methods=["POST"])
def api_reporte():
    """
    Recibe el tipo de análisis y los datos del resultado,
    genera el reporte en formato TXT y lo devuelve como descarga directa.
    El navegador lo recibe como archivo y abre el diálogo de guardar.
    """
    payload = request.get_json(silent=True) or {}
    tipo    = payload.get("tipo", "")
    datos   = payload.get("datos", {})

    if tipo not in ("phishing", "ddos"):
        return jsonify(error="Tipo inválido. Use 'phishing' o 'ddos'."), 400

    try:
        # Genero el reporte en texto plano. Esta función también guarda el
        # análisis en el historial para poder compararlo en futuras ejecuciones.
        texto = generar_txt(tipo, datos)
    except Exception as e:
        log.error("Error generando el reporte TXT: %s", e)
        return jsonify(error="No se pudo generar el reporte."), 500

    # Nombre del archivo con timestamp para que cada descarga sea única
    from datetime import datetime
    ts       = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"Reporte_FluxGuard_{tipo.upper()}_{ts}.txt"

    # Devuelvo el TXT con codificación UTF-8 y el header que fuerza la descarga
    return Response(
        texto.encode("utf-8"),
        mimetype="text/plain; charset=utf-8",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
        }
    )


@app.errorhandler(404)
def not_found(_):
    return jsonify(error="Recurso no encontrado."), 404


# ── Arranque ──────────────────────────────────────────────────────────────

def _abrir_navegador():
    """Espera un poco y abre el navegador automáticamente."""
    time.sleep(1.2)
    webbrowser.open(f"http://{config.HOST}:{config.PORT}")


if __name__ == "__main__":
    # Regenero las métricas en background antes de abrir el navegador
    t_metricas = threading.Thread(target=_regenerar_metricas, daemon=True)
    t_metricas.start()

    if config.OPEN_BROWSER:
        threading.Thread(target=_abrir_navegador, daemon=True).start()

    log.info("FluxGuard escuchando en http://%s:%s", config.HOST, config.PORT)
    app.run(host=config.HOST, port=config.PORT, debug=False, use_reloader=False)
