"""
pdf_report.py — Generador de reportes PDF profesionales para FluxGuard.

Usa reportlab para construir un PDF con portada, secciones explicativas,
métricas, gráficas de matrices de confusión y recomendaciones.
Lo llama app.py desde el endpoint /api/reporte.
"""
import os
import io
from datetime import datetime

from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    HRFlowable, Image, KeepTogether
)
from reportlab.graphics.shapes import Drawing, Rect, String, Line
from reportlab.graphics.charts.barcharts import VerticalBarChart
from reportlab.graphics import renderPDF

import config

# ── Paleta de colores FluxGuard ───────────────────────────────────────────
DARK      = colors.HexColor("#080b0f")
SURFACE   = colors.HexColor("#111620")
SURFACE2  = colors.HexColor("#161d2e")
CYAN      = colors.HexColor("#00e5ff")
GREEN     = colors.HexColor("#39ff9c")
RED       = colors.HexColor("#ff4d6a")
AMBER     = colors.HexColor("#ffb340")
INK       = colors.HexColor("#e2eaf5")
INK2      = colors.HexColor("#8fa4be")
INK3      = colors.HexColor("#4e6278")
WHITE     = colors.white
BLACK     = colors.black


def _estilos():
    """Define todos los estilos tipográficos del documento."""
    base = getSampleStyleSheet()

    estilos = {
        "titulo": ParagraphStyle(
            "titulo", parent=base["Normal"],
            fontName="Helvetica-Bold", fontSize=22,
            textColor=INK, leading=28, alignment=TA_CENTER, spaceAfter=4
        ),
        "subtitulo": ParagraphStyle(
            "subtitulo", parent=base["Normal"],
            fontName="Helvetica", fontSize=10,
            textColor=INK2, leading=14, alignment=TA_CENTER, spaceAfter=2
        ),
        "seccion": ParagraphStyle(
            "seccion", parent=base["Normal"],
            fontName="Helvetica-Bold", fontSize=12,
            textColor=CYAN, leading=16, spaceBefore=14, spaceAfter=6
        ),
        "cuerpo": ParagraphStyle(
            "cuerpo", parent=base["Normal"],
            fontName="Helvetica", fontSize=9,
            textColor=INK2, leading=14, spaceAfter=4, alignment=TA_JUSTIFY
        ),
        "cuerpo_bold": ParagraphStyle(
            "cuerpo_bold", parent=base["Normal"],
            fontName="Helvetica-Bold", fontSize=9,
            textColor=INK, leading=14, spaceAfter=3
        ),
        "mono": ParagraphStyle(
            "mono", parent=base["Normal"],
            fontName="Courier", fontSize=8,
            textColor=INK2, leading=13, spaceAfter=2
        ),
        "alerta_danger": ParagraphStyle(
            "alerta_danger", parent=base["Normal"],
            fontName="Helvetica-Bold", fontSize=11,
            textColor=RED, leading=16, alignment=TA_CENTER, spaceAfter=4
        ),
        "alerta_safe": ParagraphStyle(
            "alerta_safe", parent=base["Normal"],
            fontName="Helvetica-Bold", fontSize=11,
            textColor=GREEN, leading=16, alignment=TA_CENTER, spaceAfter=4
        ),
        "label_campo": ParagraphStyle(
            "label_campo", parent=base["Normal"],
            fontName="Helvetica-Bold", fontSize=8,
            textColor=INK3, leading=11, spaceAfter=1
        ),
        "valor_campo": ParagraphStyle(
            "valor_campo", parent=base["Normal"],
            fontName="Courier-Bold", fontSize=9,
            textColor=INK, leading=12, spaceAfter=4
        ),
        "pie": ParagraphStyle(
            "pie", parent=base["Normal"],
            fontName="Helvetica", fontSize=7,
            textColor=INK3, leading=10, alignment=TA_CENTER
        ),
        "recomendacion": ParagraphStyle(
            "recomendacion", parent=base["Normal"],
            fontName="Helvetica", fontSize=9,
            textColor=INK2, leading=14, spaceAfter=3, leftIndent=10
        ),
    }
    return estilos


def _fondo_pagina(canvas, doc):
    """
    Dibuja el fondo oscuro y la línea de acento cian en cada página.
    Se llama automáticamente por reportlab en cada página.
    """
    w, h = A4
    canvas.saveState()

    # Fondo oscuro total
    canvas.setFillColor(DARK)
    canvas.rect(0, 0, w, h, fill=1, stroke=0)

    # Línea superior cian
    canvas.setStrokeColor(CYAN)
    canvas.setLineWidth(2)
    canvas.line(20*mm, h - 12*mm, w - 20*mm, h - 12*mm)

    # Línea inferior
    canvas.setLineWidth(0.5)
    canvas.setStrokeColor(INK3)
    canvas.line(20*mm, 14*mm, w - 20*mm, 14*mm)

    # Número de página
    canvas.setFont("Helvetica", 7)
    canvas.setFillColor(INK3)
    canvas.drawCentredString(w / 2, 9*mm, f"FluxGuard v4.0  ·  Universidad Ean  ·  Página {doc.page}")

    canvas.restoreState()


def _barra_metrica(valor, maximo=100, color=CYAN, ancho=120*mm, alto=5*mm):
    """
    Devuelve un Drawing con una barra de progreso horizontal para visualizar
    el porcentaje de una métrica del modelo.
    """
    d = Drawing(ancho, alto + 2*mm)

    # Fondo de la barra
    d.add(Rect(0, 2*mm, ancho, alto,
               fillColor=colors.HexColor("#161d2e"), strokeColor=INK3, strokeWidth=0.3))

    # Relleno proporcional al valor
    fill_w = ancho * (valor / maximo)
    if fill_w > 0:
        d.add(Rect(0, 2*mm, fill_w, alto,
                   fillColor=color, strokeColor=None))
    return d


def _grafica_barras_metricas(modelos):
    """
    Genera un gráfico de barras agrupado con las métricas de todos los modelos.
    Exactitud, Precisión, Recall y F1 para cada algoritmo.
    """
    d = Drawing(160*mm, 70*mm)

    bc = VerticalBarChart()
    bc.x       = 15*mm
    bc.y       = 10*mm
    bc.width   = 140*mm
    bc.height  = 55*mm

    # Datos: cada sublista es una métrica, cada elemento es un modelo
    datos = [
        [m["exactitud"] for m in modelos],
        [m["precision"] for m in modelos],
        [m["recall"]    for m in modelos],
        [m["f1"]        for m in modelos],
    ]
    bc.data = datos

    bc.categoryAxis.categoryNames = [m["nombre_corto"] for m in modelos]
    bc.categoryAxis.labels.fontName  = "Helvetica"
    bc.categoryAxis.labels.fontSize  = 7
    bc.categoryAxis.labels.fillColor = INK2
    bc.categoryAxis.labels.angle     = 10

    bc.valueAxis.valueMin   = 80
    bc.valueAxis.valueMax   = 101
    bc.valueAxis.valueStep  = 5
    bc.valueAxis.labels.fontName  = "Helvetica"
    bc.valueAxis.labels.fontSize  = 7
    bc.valueAxis.labels.fillColor = INK2

    colores_barras = [CYAN, GREEN, AMBER, RED]
    for i, c in enumerate(colores_barras):
        bc.bars[i].fillColor   = c
        bc.bars[i].strokeColor = None

    bc.barSpacing    = 1
    bc.groupSpacing  = 4
    bc.valueAxis.strokeColor    = INK3
    bc.categoryAxis.strokeColor = INK3

    d.add(bc)

    # Leyenda manual
    leyendas = ["Exactitud", "Precisión", "Recall", "F1-Score"]
    for i, (lbl, col) in enumerate(zip(leyendas, colores_barras)):
        x = 15*mm + i * 37*mm
        d.add(Rect(x, 2*mm, 8, 5, fillColor=col, strokeColor=None))
        d.add(String(x + 10, 2.5*mm, lbl,
                     fontName="Helvetica", fontSize=6.5, fillColor=INK2))
    return d


def generar_pdf(tipo: str, datos: dict) -> bytes:
    """
    Función principal. Recibe el tipo de análisis ("phishing" o "ddos")
    y los datos del resultado, y devuelve el PDF como bytes para enviarlo
    directamente desde Flask sin guardar archivo en disco.
    """
    buf    = io.BytesIO()
    doc    = SimpleDocTemplate(
        buf, pagesize=A4,
        leftMargin=20*mm, rightMargin=20*mm,
        topMargin=18*mm, bottomMargin=18*mm
    )
    E  = _estilos()
    ts = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    contenido = []

    # ── PORTADA ──────────────────────────────────────────────────────────
    contenido.append(Spacer(1, 8*mm))
    contenido.append(Paragraph("FluxGuard", E["titulo"]))
    contenido.append(Paragraph("Sistema Integral de Análisis y Mitigación de Vulnerabilidades", E["subtitulo"]))
    contenido.append(Paragraph("DDoS &amp; Phishing · Universidad Ean · Ingeniería de Sistemas", E["subtitulo"]))
    contenido.append(Spacer(1, 3*mm))
    contenido.append(HRFlowable(width="100%", thickness=0.5, color=CYAN, spaceAfter=4))

    # Tipo de reporte y estado
    tipo_label = "PHISHING" if tipo == "phishing" else "ATAQUE DDoS"
    contenido.append(Paragraph(
        f"REPORTE DE INCIDENTE — {tipo_label}",
        E["alerta_danger"] if datos.get("estado") == "peligro" else E["alerta_safe"]
    ))

    # Tabla de cabecera con fecha y estado
    estado_txt  = "⚠ AMENAZA DETECTADA" if datos.get("estado") == "peligro" else "✓ SEGURO"
    estado_col  = RED if datos.get("estado") == "peligro" else GREEN
    cab_data = [
        ["Fecha y hora del análisis", ts],
        ["Tipo de análisis",          tipo_label],
        ["Resultado",                 estado_txt],
    ]
    cab_table = Table(cab_data, colWidths=[60*mm, 110*mm])
    cab_table.setStyle(TableStyle([
        ("BACKGROUND",   (0,0), (-1,-1), SURFACE),
        ("TEXTCOLOR",    (0,0), (0,-1),  INK3),
        ("TEXTCOLOR",    (1,0), (1,-1),  INK),
        ("TEXTCOLOR",    (1,2), (1,2),   estado_col),
        ("FONTNAME",     (0,0), (0,-1),  "Helvetica"),
        ("FONTNAME",     (1,0), (1,-1),  "Helvetica-Bold"),
        ("FONTSIZE",     (0,0), (-1,-1), 9),
        ("ROWBACKGROUNDS",(0,0),(-1,-1), [SURFACE, SURFACE2]),
        ("GRID",         (0,0), (-1,-1), 0.3, INK3),
        ("LEFTPADDING",  (0,0), (-1,-1), 8),
        ("RIGHTPADDING", (0,0), (-1,-1), 8),
        ("TOPPADDING",   (0,0), (-1,-1), 5),
        ("BOTTOMPADDING",(0,0), (-1,-1), 5),
    ]))
    contenido.append(cab_table)
    contenido.append(Spacer(1, 5*mm))

    # ── SECCIÓN ESPECÍFICA POR TIPO ───────────────────────────────────────
    if tipo == "phishing":
        _seccion_phishing(contenido, datos, E)
    else:
        _seccion_ddos(contenido, datos, E)

    # ── SECCIÓN: MÉTRICAS DEL MODELO ────────────────────────────────────
    contenido.append(HRFlowable(width="100%", thickness=0.3, color=INK3, spaceBefore=6, spaceAfter=4))
    contenido.append(Paragraph("Rendimiento del Modelo de Machine Learning", E["seccion"]))

    modelos_info = [
        {"nombre": "Random Forest",            "nombre_corto": "RF-DDoS",   "exactitud": 97.00, "precision": 96.48, "recall": 96.91, "f1": 96.69},
        {"nombre": "Decision Tree",            "nombre_corto": "DT-DDoS",   "exactitud": 96.33, "precision": 95.75, "recall": 96.17, "f1": 95.96},
        {"nombre": "Isolation Forest",         "nombre_corto": "IF-DDoS",   "exactitud": 93.07, "precision": 88.49, "recall": 97.35, "f1": 92.71},
        {"nombre": "RF Phishing",              "nombre_corto": "RF-Phish",  "exactitud":100.00, "precision":100.00, "recall":100.00, "f1":100.00},
    ]

    # Tabla de métricas
    met_header = ["Modelo", "Exactitud", "Precisión", "Recall", "F1-Score", "Latencia"]
    met_rows   = [met_header]
    latencias  = ["0.013 ms", "0.000 ms", "0.010 ms", "0.254 ms"]
    for m, lat in zip(modelos_info, latencias):
        met_rows.append([
            m["nombre"],
            f"{m['exactitud']:.2f}%",
            f"{m['precision']:.2f}%",
            f"{m['recall']:.2f}%",
            f"{m['f1']:.2f}%",
            lat,
        ])
    met_table = Table(met_rows, colWidths=[42*mm, 24*mm, 24*mm, 22*mm, 22*mm, 22*mm])
    met_table.setStyle(TableStyle([
        ("BACKGROUND",   (0,0), (-1,0),  SURFACE2),
        ("TEXTCOLOR",    (0,0), (-1,0),  CYAN),
        ("FONTNAME",     (0,0), (-1,0),  "Helvetica-Bold"),
        ("FONTSIZE",     (0,0), (-1,-1), 8),
        ("ROWBACKGROUNDS",(0,1),(-1,-1), [SURFACE, SURFACE2]),
        ("TEXTCOLOR",    (0,1), (0,-1),  INK),
        ("TEXTCOLOR",    (1,1), (-1,-1), GREEN),
        ("FONTNAME",     (1,1), (-1,-1), "Courier-Bold"),
        ("GRID",         (0,0), (-1,-1), 0.3, INK3),
        ("ALIGN",        (1,0), (-1,-1), "CENTER"),
        ("LEFTPADDING",  (0,0), (-1,-1), 6),
        ("RIGHTPADDING", (0,0), (-1,-1), 6),
        ("TOPPADDING",   (0,0), (-1,-1), 4),
        ("BOTTOMPADDING",(0,0), (-1,-1), 4),
    ]))
    contenido.append(met_table)
    contenido.append(Spacer(1, 4*mm))

    # Gráfica de barras comparativa
    contenido.append(Paragraph("Comparativa visual de métricas por algoritmo:", E["cuerpo_bold"]))
    contenido.append(_grafica_barras_metricas(modelos_info))
    contenido.append(Spacer(1, 3*mm))

    # ── MATRICES DE CONFUSIÓN (imágenes PNG) ─────────────────────────────
    img_map = {
        "phishing": [("cm_phishing_rf.png", "Random Forest — Phishing")],
        "ddos":     [
            ("cm_ddos_rf.png", "Random Forest — DDoS"),
            ("cm_ddos_dt.png", "Decision Tree — DDoS"),
            ("cm_ddos_if.png", "Isolation Forest — DDoS"),
        ],
    }
    pngs_disponibles = []
    for fname, titulo_img in img_map.get(tipo, []):
        ruta = os.path.join(config.OUTPUT_DIR, fname)
        if os.path.exists(ruta):
            pngs_disponibles.append((ruta, titulo_img))

    if pngs_disponibles:
        contenido.append(HRFlowable(width="100%", thickness=0.3, color=INK3, spaceBefore=4, spaceAfter=4))
        contenido.append(Paragraph("Matrices de Confusión del Modelo", E["seccion"]))
        contenido.append(Paragraph(
            "Una matriz de confusión muestra cuántas predicciones fueron correctas "
            "(diagonal principal) e incorrectas. Cuanto mayor sea el número en la diagonal, "
            "mejor es el modelo.", E["cuerpo"]
        ))
        contenido.append(Spacer(1, 3*mm))

        # Las muestro en fila si son varias, o centrada si es una
        if len(pngs_disponibles) == 1:
            ruta, titulo_img = pngs_disponibles[0]
            contenido.append(Paragraph(titulo_img, E["cuerpo_bold"]))
            contenido.append(Image(ruta, width=80*mm, height=68*mm))
        else:
            # Tres imágenes en una fila de tabla
            fila_imgs = []
            fila_labs = []
            for ruta, titulo_img in pngs_disponibles:
                fila_imgs.append(Image(ruta, width=55*mm, height=47*mm))
                fila_labs.append(Paragraph(titulo_img, E["label_campo"]))
            t_imgs = Table([fila_labs, fila_imgs], colWidths=[55*mm]*3)
            t_imgs.setStyle(TableStyle([
                ("ALIGN",  (0,0), (-1,-1), "CENTER"),
                ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
                ("LEFTPADDING",  (0,0), (-1,-1), 3),
                ("RIGHTPADDING", (0,0), (-1,-1), 3),
            ]))
            contenido.append(t_imgs)

    # ── PIE DE PÁGINA FINAL ───────────────────────────────────────────────
    contenido.append(Spacer(1, 6*mm))
    contenido.append(HRFlowable(width="100%", thickness=0.5, color=CYAN, spaceAfter=3))
    contenido.append(Paragraph(
        f"Generado por FluxGuard v4.0  ·  {ts}  ·  "
        "Universidad Ean · Facultad de Ingeniería · Ingeniería de Sistemas · Bogotá, Colombia",
        E["pie"]
    ))

    # ── CONSTRUIR EL PDF ─────────────────────────────────────────────────
    doc.build(contenido, onFirstPage=_fondo_pagina, onLaterPages=_fondo_pagina)
    buf.seek(0)
    return buf.read()


# ── SECCIONES ESPECÍFICAS ─────────────────────────────────────────────────

def _seccion_phishing(contenido, d, E):
    """Construye las secciones del reporte para análisis de phishing."""
    es_peligro = d.get("estado") == "peligro"

    # Métricas del análisis
    contenido.append(Paragraph("Resultado del Análisis", E["seccion"]))
    filas_res = [
        ["Confianza del modelo", f"{d.get('confianza', 0)}%"],
        ["Veredicto",            d.get("mensaje", "—")],
    ]
    t = Table(filas_res, colWidths=[60*mm, 110*mm])
    t.setStyle(TableStyle([
        ("ROWBACKGROUNDS", (0,0), (-1,-1), [SURFACE, SURFACE2]),
        ("TEXTCOLOR",  (0,0), (0,-1), INK3),
        ("TEXTCOLOR",  (1,0), (1,-1), INK),
        ("FONTNAME",   (0,0), (0,-1), "Helvetica"),
        ("FONTNAME",   (1,0), (1,-1), "Helvetica-Bold"),
        ("FONTSIZE",   (0,0), (-1,-1), 9),
        ("GRID",       (0,0), (-1,-1), 0.3, INK3),
        ("LEFTPADDING",(0,0), (-1,-1), 8),
        ("TOPPADDING", (0,0), (-1,-1), 5),
        ("BOTTOMPADDING",(0,0),(-1,-1), 5),
    ]))
    contenido.append(t)
    contenido.append(Spacer(1, 2*mm))

    # Barra de confianza
    contenido.append(Paragraph("Nivel de confianza del modelo:", E["label_campo"]))
    contenido.append(_barra_metrica(
        d.get("confianza", 0),
        color=RED if es_peligro else GREEN,
        ancho=170*mm
    ))
    contenido.append(Spacer(1, 5*mm))

    # Explicación del phishing
    contenido.append(Paragraph("¿Qué es el Phishing?", E["seccion"]))
    contenido.append(Paragraph(
        "El phishing es una técnica de ingeniería social mediante la cual un atacante envía un correo "
        "electrónico fraudulento suplantando la identidad de una entidad confiable (banco, empresa, "
        "entidad gubernamental) con el objetivo de robar contraseñas, datos bancarios o información "
        "personal. En Colombia, el 74% de las brechas de seguridad registradas en 2024 iniciaron con "
        "un correo de phishing. (Fuente: ACIS / Policía Nacional, 2025).", E["cuerpo"]
    ))
    contenido.append(Spacer(1, 3*mm))

    # Cómo lo detectó FluxGuard
    contenido.append(Paragraph("¿Cómo lo detectó FluxGuard?", E["seccion"]))
    pasos = [
        ("1. TF-IDF (Análisis semántico del texto)",
         "Convierte el texto del correo en vectores numéricos. Detecta palabras de urgencia y coerción "
         "como 'urgente', 'bloqueo', 'verifique', 'premio', 'haga clic ahora'. Los correos de phishing "
         "usan este lenguaje para presionar al usuario a actuar sin pensar."),
        ("2. Análisis estructural de la URL",
         "Examina el enlace incluido y extrae señales sospechosas: IP numérica en vez de dominio "
         "(ej: http://192.168.1.1/login), TLDs peligrosos (.win .xyz .click .ru .top), símbolo @ "
         "en la URL (oculta el destino real), ausencia de HTTPS, longitud excesiva con subdominios falsos."),
        ("3. Random Forest (120 árboles de decisión)",
         "Combina todas las señales anteriores y calcula una probabilidad final. Si ≥ 50%, activa "
         "la alerta de phishing. El modelo fue entrenado con 89 correos etiquetados (49 phishing + "
         "40 legítimos) y evaluado en 27 muestras independientes con 100% de exactitud."),
    ]
    for titulo_paso, desc_paso in pasos:
        contenido.append(KeepTogether([
            Paragraph(titulo_paso, E["cuerpo_bold"]),
            Paragraph(desc_paso, E["cuerpo"]),
            Spacer(1, 2*mm),
        ]))

    # Recomendaciones
    contenido.append(Paragraph("Recomendaciones", E["seccion"]))
    if es_peligro:
        recs = [
            "⚠  NO haga clic en ningún enlace del correo analizado.",
            "⚠  NO descargue archivos adjuntos del remitente.",
            "⚠  NO ingrese contraseñas, datos bancarios ni información personal.",
            "✓  Reporte el correo como spam/phishing en su cliente de correo.",
            "✓  Si ya ingresó datos, cambie sus contraseñas de inmediato.",
            "✓  Notifique a su área de TI o al administrador de seguridad.",
            "✓  Contacte a su banco si proporcionó datos financieros.",
        ]
    else:
        recs = [
            "✓  El correo no presenta indicadores de phishing.",
            "✓  Aun así, sea cauteloso con correos inesperados que soliciten información sensible.",
            "✓  Verifique siempre la dirección del remitente, no solo su nombre visible.",
            "✓  Ante la duda, contacte directamente a la entidad por canales oficiales.",
        ]
    for r in recs:
        contenido.append(Paragraph(r, E["recomendacion"]))
    contenido.append(Spacer(1, 3*mm))


def _seccion_ddos(contenido, d, E):
    """Construye las secciones del reporte para análisis de tráfico DDoS."""
    es_ataque  = d.get("estado") == "peligro"
    datos_red  = d.get("datos", {})
    pps        = datos_red.get("pps",      d.get("pps",      "—"))
    latencia   = datos_red.get("latencia", "—")
    bw         = datos_red.get("bw",       "—")
    tipo_atk   = d.get("tipo", "Tráfico normal")
    ip         = d.get("ip", "—")
    tiempo_det = d.get("tiempo", "—")

    # Tabla de métricas de red capturadas
    contenido.append(Paragraph("Métricas de Red Capturadas", E["seccion"]))
    filas_red = [
        ["IP de origen",          str(ip)],
        ["PPS (Paquetes/segundo)", str(pps)],
        ["Latencia",              f"{latencia} ms"],
        ["Ancho de banda",        f"{bw} Mbps"],
        ["Tipo de ataque",        str(tipo_atk)],
        ["Tiempo de detección",   f"{tiempo_det} s" if tiempo_det != "—" else "—"],
    ]
    t = Table(filas_red, colWidths=[60*mm, 110*mm])
    t.setStyle(TableStyle([
        ("ROWBACKGROUNDS", (0,0), (-1,-1), [SURFACE, SURFACE2]),
        ("TEXTCOLOR",  (0,0), (0,-1), INK3),
        ("TEXTCOLOR",  (1,0), (1,-1), INK),
        ("FONTNAME",   (0,0), (0,-1), "Helvetica"),
        ("FONTNAME",   (1,0), (1,-1), "Courier-Bold"),
        ("FONTSIZE",   (0,0), (-1,-1), 9),
        ("GRID",       (0,0), (-1,-1), 0.3, INK3),
        ("LEFTPADDING",(0,0), (-1,-1), 8),
        ("TOPPADDING", (0,0), (-1,-1), 5),
        ("BOTTOMPADDING",(0,0),(-1,-1), 5),
    ]))
    contenido.append(t)
    contenido.append(Spacer(1, 3*mm))

    # Barras visuales de saturación
    if es_ataque and pps != "—":
        contenido.append(Paragraph("Nivel de saturación de red:", E["label_campo"]))
        pps_pct = min(float(pps) / 50000 * 100, 100) if str(pps).replace('.','').isdigit() else 0
        bw_pct  = min(float(bw)  / 80    * 100, 100) if str(bw).replace('.','').isdigit()  else 0
        contenido.append(Paragraph(f"Carga PPS ({pps} pps)", E["mono"]))
        contenido.append(_barra_metrica(pps_pct, color=RED,   ancho=170*mm))
        contenido.append(Spacer(1, 1*mm))
        contenido.append(Paragraph(f"Ancho de banda ({bw} Mbps)", E["mono"]))
        contenido.append(_barra_metrica(bw_pct,  color=AMBER, ancho=170*mm))
        contenido.append(Spacer(1, 4*mm))

    # Explicación de cada métrica en términos simples
    contenido.append(Paragraph("¿Qué significa cada métrica?", E["seccion"]))
    metricas_exp = [
        ("PPS — Paquetes Por Segundo",
         f"Indica cuántos paquetes de datos llegan al servidor por segundo. "
         f"En condiciones normales: 200–1.000 PPS. "
         f"Por encima de 50.000 PPS es señal de inundación masiva. "
         f"Valor detectado: {pps} PPS. "
         + ("⚠ CRÍTICO — muy por encima del umbral." if str(pps).replace('.','').isdigit() and float(pps) > 50000 else "✓ Dentro del rango normal.")),
        ("Latencia (ms)",
         f"Tiempo que tarda un paquete en llegar al servidor y regresar. "
         f"Normal: 20–80 ms. Sobre 300 ms indica saturación o ataque de capa 7. "
         f"Valor detectado: {latencia} ms. "
         + ("⚠ CRÍTICO — el servidor responde con retraso severo." if str(latencia).replace('.','').isdigit() and float(latencia) > 300 else "✓ Dentro del rango normal.")),
        ("Ancho de banda (Mbps)",
         f"Cantidad de datos que fluyen hacia el servidor por segundo. "
         f"Normal para una microempresa: 5–30 Mbps. "
         f"Sobre 80 Mbps indica ataque volumétrico. "
         f"Valor detectado: {bw} Mbps. "
         + ("⚠ CRÍTICO — saturación de ancho de banda." if str(bw).replace('.','').isdigit() and float(bw) > 80 else "✓ Dentro del rango normal.")),
    ]
    for titulo_m, desc_m in metricas_exp:
        contenido.append(KeepTogether([
            Paragraph(titulo_m, E["cuerpo_bold"]),
            Paragraph(desc_m, E["cuerpo"]),
            Spacer(1, 2*mm),
        ]))

    # Explicación del tipo de ataque
    if es_ataque:
        explicaciones = {
            "Volumétrico (UDP/ICMP Flood)":
                "Inunda el ancho de banda con paquetes UDP/ICMP masivos desde botnets. "
                "El objetivo es saturar la conexión de internet hasta dejarla inaccesible. "
                "Opera en las capas 3 y 4 del modelo OSI.",
            "De Protocolo (SYN Flood)":
                "Explota el proceso TCP de tres vías enviando miles de solicitudes SYN sin completarlas. "
                "Agota la tabla de conexiones del servidor, impidiéndole aceptar conexiones legítimas.",
            "Capa de Aplicación (Slowloris / Low & Slow)":
                "Mantiene cientos de conexiones HTTP abiertas y semi-completas con mínimo tráfico. "
                "Es el más difícil de detectar porque imita comportamiento legítimo. "
                "Afecta servidores web sin saturar la red.",
            "Patrón Mixto":
                "El tráfico presenta múltiples indicadores anómalos de distintas categorías. "
                "Puede ser un ataque compuesto o un vector nuevo no catalogado.",
        }
        exp = explicaciones.get(tipo_atk, "Anomalía estadística detectada por Isolation Forest.")
        contenido.append(Paragraph(f"Tipo de ataque detectado: {tipo_atk}", E["seccion"]))
        contenido.append(Paragraph(exp, E["cuerpo"]))
        contenido.append(Spacer(1, 3*mm))

    # Explicación del algoritmo
    contenido.append(Paragraph("¿Cómo lo detectó FluxGuard?", E["seccion"]))
    contenido.append(Paragraph(
        "FluxGuard utiliza Isolation Forest, un algoritmo de aprendizaje no supervisado que aprende "
        "el comportamiento normal de la red (PPS, latencia, ancho de banda, SYN ratio) y detecta "
        "cualquier desviación estadística significativa como un ataque — incluso botnets nuevas que "
        "nunca ha visto antes, sin necesidad de una base de datos de firmas actualizada.", E["cuerpo"]
    ))
    contenido.append(Spacer(1, 3*mm))

    # Recomendaciones
    contenido.append(Paragraph("Recomendaciones", E["seccion"]))
    if es_ataque:
        recs = [
            f"⚠  Active rate limiting en el router/firewall de inmediato.",
            f"⚠  Bloquee la IP {ip} en las reglas de iptables o en el firewall.",
            "⚠  Contacte a su ISP (proveedor de internet) para filtrado upstream.",
            "✓  Documente el incidente: hora, IP, PPS, latencia y ancho de banda.",
            "✓  Considere activar un servicio CDN con mitigación DDoS (Cloudflare, AWS Shield).",
            "✓  Notifique al ColCERT — Equipo Nacional de Respuesta a Emergencias Cibernéticas.",
        ]
    else:
        recs = [
            "✓  El tráfico analizado es normal. No se requiere acción inmediata.",
            "✓  Mantenga el monitoreo activo y repita el análisis periódicamente.",
            "✓  Establezca umbrales de alerta automáticos para PPS y ancho de banda.",
        ]
    for r in recs:
        contenido.append(Paragraph(r, E["recomendacion"]))
    contenido.append(Spacer(1, 3*mm))
