"""
config.py — Configuración central de FluxGuard.

Toda constante "ajustable" vive aquí: parámetros de modelos, umbrales de la
capa experta, límites de validación y ajustes del servidor. Cambiar un valor
no exige tocar el resto del código.
"""
import os

# --- Servidor web ---
HOST = os.getenv("FLUXGUARD_HOST", "127.0.0.1")
PORT = int(os.getenv("FLUXGUARD_PORT", "5000"))
OPEN_BROWSER = os.getenv("FLUXGUARD_OPEN_BROWSER", "1") == "1"

# --- Reproducibilidad ---
SEED = 42

# --- Modelos de Machine Learning (parámetros bajos = aptos para hardware limitado) ---
RF_TREES = 120            # Random Forest
DT_MAX_DEPTH = 8          # Decision Tree (control de sobreajuste)
IF_TREES = 120            # Isolation Forest
IF_CONTAMINATION = 0.10   # proporción esperada de anomalías
TFIDF_MAX_FEATURES = 300

# --- Umbrales de la capa experta (clasificación del TIPO de ataque DDoS) ---
TH_BW_VOLUMETRIC = 80     # Mbps  -> volumétrico
TH_PPS_PROTOCOL = 50000   # pps   -> protocolo (SYN flood)
TH_LAT_APP = 300          # ms    -> capa de aplicación (low & slow)
TH_BW_APP = 50            # Mbps

# --- Límites de validación de entrada de la API ---
MAX_TEXT_LEN = 5000
PPS_RANGE = (0, 10_000_000)
LAT_RANGE = (0, 60_000)
BW_RANGE = (0, 1_000_000)
IP_MAX_LEN = 45

# --- Rutas de datos / salidas ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(BASE_DIR, "outputs")
# Si colocas el CSV real de CICDDoS2019 aquí, evaluate.py lo usará automáticamente.
CICDDOS_CSV = os.getenv("CICDDOS_CSV", os.path.join(BASE_DIR, "data", "cicddos2019.csv"))
