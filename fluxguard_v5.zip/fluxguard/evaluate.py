"""
evaluate.py — Harness de evaluación reproducible de FluxGuard.

Genera la EVIDENCIA que el documento de grado afirma:
  - Tabla de métricas (exactitud, precisión, recall, F1, latencia) para
    Random Forest, Decision Tree (supervisados) e Isolation Forest (no superv.)
    en la tarea de detección DDoS  -> corresponde a la Tabla 4 del documento.
  - Métricas del módulo de phishing (TF-IDF + features de URL).
  - Matrices de confusión guardadas como PNG  -> para la Figura 2 del documento.
  - Un CSV con todos los resultados.

Uso:
    python evaluate.py
Con el dataset real:
    CICDDOS_CSV=ruta/cicddos2019.csv python evaluate.py

IMPORTANTE: las cifras dependen de los datos. Con el benchmark sintético sirven
para demostrar el método; para el documento, usa CICDDoS2019 y reporta ESAS.
"""
import os
import time
import logging

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")  # backend sin pantalla
import matplotlib.pyplot as plt
import seaborn as sns

from scipy.sparse import hstack, csr_matrix
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, IsolationForest
from sklearn.tree import DecisionTreeClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             f1_score, confusion_matrix)

import config
import data

logging.basicConfig(level=logging.INFO, format="%(message)s")
log = logging.getLogger("evaluate")
os.makedirs(config.OUTPUT_DIR, exist_ok=True)


def _metricas(y_true, y_pred, t_pred_ms):
    return {
        "Exactitud": round(accuracy_score(y_true, y_pred) * 100, 2),
        "Precision": round(precision_score(y_true, y_pred, zero_division=0) * 100, 2),
        "Recall": round(recall_score(y_true, y_pred, zero_division=0) * 100, 2),
        "F1": round(f1_score(y_true, y_pred, zero_division=0) * 100, 2),
        "Latencia_ms": round(t_pred_ms, 3),
    }


def _matriz_confusion(y_true, y_pred, titulo, archivo):
    cm = confusion_matrix(y_true, y_pred)
    plt.figure(figsize=(4.2, 3.6))
    sns.heatmap(cm, annot=True, fmt="d", cmap="YlGn", cbar=False,
                xticklabels=["Normal", "Ataque"], yticklabels=["Normal", "Ataque"])
    plt.title(titulo, fontsize=11, weight="bold")
    plt.ylabel("Real"); plt.xlabel("Predicho")
    plt.tight_layout()
    ruta = os.path.join(config.OUTPUT_DIR, archivo)
    plt.savefig(ruta, dpi=150); plt.close()
    return ruta


# ==========================================================================
# 1. DETECCIÓN DDoS — RF y Decision Tree (supervisados) + Isolation Forest
# ==========================================================================
def evaluar_ddos():
    traf, fuente = data.cargar_ddos()
    log.info("\n=== DDoS — fuente de datos: %s (%d muestras) ===", fuente, len(traf))
    X = traf[data.DDOS_FEATURES].to_numpy()
    y = traf["label"].to_numpy()
    X_tr, X_te, y_tr, y_te = train_test_split(
        X, y, test_size=0.30, random_state=config.SEED, stratify=y)

    resultados = {}

    # --- Random Forest (supervisado) ---
    rf = RandomForestClassifier(n_estimators=config.RF_TREES, random_state=config.SEED)
    rf.fit(X_tr, y_tr)
    t0 = time.perf_counter(); pred = rf.predict(X_te)
    t_ms = (time.perf_counter() - t0) / len(X_te) * 1000
    resultados["Random Forest"] = _metricas(y_te, pred, t_ms)
    _matriz_confusion(y_te, pred, "Random Forest — DDoS", "cm_ddos_rf.png")

    # --- Decision Tree (supervisado) — faltaba en el código original ---
    dt = DecisionTreeClassifier(max_depth=config.DT_MAX_DEPTH, random_state=config.SEED)
    dt.fit(X_tr, y_tr)
    t0 = time.perf_counter(); pred = dt.predict(X_te)
    t_ms = (time.perf_counter() - t0) / len(X_te) * 1000
    resultados["Decision Tree"] = _metricas(y_te, pred, t_ms)
    _matriz_confusion(y_te, pred, "Decision Tree — DDoS", "cm_ddos_dt.png")

    # --- Isolation Forest (NO supervisado: entrena solo con normales) ---
    iforest = IsolationForest(n_estimators=config.IF_TREES,
                              contamination=config.IF_CONTAMINATION, random_state=config.SEED)
    iforest.fit(X_tr[y_tr == 0])  # solo tráfico normal
    t0 = time.perf_counter(); raw = iforest.predict(X_te)
    t_ms = (time.perf_counter() - t0) / len(X_te) * 1000
    pred = np.where(raw == -1, 1, 0)  # -1 anomalía -> ataque
    resultados["Isolation Forest"] = _metricas(y_te, pred, t_ms)
    _matriz_confusion(y_te, pred, "Isolation Forest — DDoS", "cm_ddos_if.png")

    return pd.DataFrame(resultados).T, fuente


# ==========================================================================
# 2. DETECCIÓN DE PHISHING — TF-IDF + features de URL (Random Forest)
# ==========================================================================
def evaluar_phishing():
    df = data.cargar_phishing()
    log.info("\n=== Phishing — corpus: %d correos ===", len(df))
    idx_tr, idx_te = train_test_split(
        df.index, test_size=0.30, random_state=config.SEED, stratify=df["label"])

    vec = TfidfVectorizer(max_features=config.TFIDF_MAX_FEATURES)
    txt_tr = (df.loc[idx_tr, "texto"] + " " + df.loc[idx_tr, "url"])
    txt_te = (df.loc[idx_te, "texto"] + " " + df.loc[idx_te, "url"])
    Xt_tr = vec.fit_transform(txt_tr)
    Xt_te = vec.transform(txt_te)
    Xu_tr = csr_matrix(df.loc[idx_tr, data.FEATURE_COLS].to_numpy(dtype=float))
    Xu_te = csr_matrix(df.loc[idx_te, data.FEATURE_COLS].to_numpy(dtype=float))
    X_tr = hstack([Xt_tr, Xu_tr]); X_te = hstack([Xt_te, Xu_te])
    y_tr = df.loc[idx_tr, "label"]; y_te = df.loc[idx_te, "label"]

    rf = RandomForestClassifier(n_estimators=config.RF_TREES, random_state=config.SEED,
                                class_weight="balanced")
    rf.fit(X_tr, y_tr)
    t0 = time.perf_counter(); pred = rf.predict(X_te)
    t_ms = (time.perf_counter() - t0) / len(idx_te) * 1000
    _matriz_confusion(y_te, pred, "Random Forest — Phishing", "cm_phishing_rf.png")
    return pd.DataFrame({"Random Forest (Phishing)": _metricas(y_te, pred, t_ms)}).T


# ==========================================================================
# 3. MAIN
# ==========================================================================
def main():
    ddos, fuente = evaluar_ddos()
    phish = evaluar_phishing()

    tabla = pd.concat([ddos, phish])
    log.info("\n================ RESULTADOS (Tabla 4 reproducible) ================")
    log.info("\n%s", tabla.to_string())

    csv = os.path.join(config.OUTPUT_DIR, "metricas.csv")
    tabla.to_csv(csv)
    log.info("\n[OK] Métricas guardadas en: %s", csv)
    log.info("[OK] Matrices de confusión PNG guardadas en: %s", config.OUTPUT_DIR)
    log.info("[fuente DDoS] %s", fuente)


if __name__ == "__main__":
    main()
