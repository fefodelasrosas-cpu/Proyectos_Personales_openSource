"""
data.py — Generación y carga de datos para FluxGuard.

Acá tengo todo lo relacionado con los datos que usa el sistema para
aprender a detectar phishing y tráfico DDoS. Lo dividí en tres partes:
  1. Corpus de phishing expandido (texto + URL) con features estructurales
  2. Generador de tráfico de red etiquetado (normal + 3 tipos de ataque)
  3. Hook para conectar el dataset real CICDDoS2019 si está disponible

Nota: el corpus sintético sirve para demostrar el pipeline. Para métricas
definitivas, coloca CICDDoS2019 en data/ y re-ejecuta evaluate.py.
"""
import re
import numpy as np
import pandas as pd
import config

# ==========================================================================
# 1. PHISHING — corpus expandido (1 = phishing, 0 = legítimo)
#    Aumenté el corpus a ~120 muestras para que las métricas sean más sólidas
#    y el modelo se evalúe en ~36 correos en vez de 12.
# ==========================================================================
_PHISHING = [
    # --- Suplantación bancaria y financiera ---
    ("Actualice su contrasena urgente o su cuenta sera bloqueada hoy", "http://banco-seguro-login.com/verify?id=901"),
    ("Su cuenta sera suspendida verifique sus datos ahora mismo", "http://192.168.45.11/account/confirm"),
    ("Detectamos actividad sospechosa confirme su tarjeta de credito", "http://secure-update-paypaI.com/login"),
    ("Ha recibido una transferencia confirme con su clave dinamica", "http://bancolombia-clientes.secure-co.ru/tx"),
    ("Click here to reset your bank password it expires in one hour", "http://reset-bank-password.online/reset"),
    ("Reembolso pendiente ingrese sus datos para recibir el pago", "http://dian-reembolso-gov.co.verify-tax.com/refund"),
    ("Su tarjeta fue bloqueada por movimientos inusuales desbloquee ya", "http://tarjeta-bloqueo-bbva.xyz/unlock?id=7721"),
    ("Urgente su credito fue aprobado confirme sus datos bancarios hoy", "http://credito-aprobado-davivienda.click/confirm"),
    ("Transferencia rechazada verifique cuenta para no perder el dinero", "http://pse-verificacion-banco.info/check"),
    ("Your PayPal account has been limited verify your identity now", "http://paypal-verify-account-ltd.com/secure"),
    ("Bancolombia: hemos detectado un intento de fraude confirme su clave", "http://bancolombia-alerta.ru/clave"),
    ("Su extracto digital esta disponible ingrese para descargarlo ahora", "http://extracto-digital-banco.win/login"),
    ("Nequi: movimiento sospechoso en su cuenta active proteccion ya", "http://nequi-proteccion.biz/activate"),
    ("Alerta fraude en su cuenta de ahorros llame o confirme de inmediato", "http://192.0.2.55/cuenta/confirmar"),
    ("DIAN: tiene una devolucion de impuestos pendiente reclamela aqui", "http://dian-devolucion-impuesto.top/reclamar"),

    # --- Premios y sorteos falsos ---
    ("Felicidades ha ganado un premio reclamelo aqui antes de 24 horas", "http://premios-loteria-internacional.win/claim"),
    ("Premio loteria internacional reclame su millon de dolares hoy", "http://winner-lottery-prize.top/claim?ref=88"),
    ("Gane un iphone gratis solo confirme sus datos personales", "http://iphone-gratis-sorteo.win/confirm"),
    ("Has sido seleccionado para recibir un bono de compras de 500 dolares", "http://bono-compras-seleccionado.xyz/canjear"),
    ("Ganaste un viaje a Cancun confirma tu identidad para reclamarlo", "http://viaje-cancun-premio.click/identidad"),
    ("Enhorabuena su numero fue elegido en el sorteo internacional", "http://sorteo-ganador-2026.info/premio"),
    ("Su direccion de correo fue elegida para un premio especial hoy", "http://correo-elegido-premio.online/especial"),

    # --- Suplantación de servicios y plataformas ---
    ("Your account has been locked click here to verify your identity now", "http://apple-id-verify-support.net/unlock"),
    ("Urgent payment required update your billing information immediately", "http://billing-update-amaz0n.com/pay"),
    ("Your package could not be delivered confirm address and card", "http://tracking-delivery-confirm.info/parcel"),
    ("Verify your account to avoid suspension click the link below", "http://micr0soft-account-team.com/verify"),
    ("Security alert unusual sign in verify your password immediately", "http://account-security-alert.com/verify?u=1"),
    ("Invoice attached please pay immediately via wire transfer", "http://invoice-payment-urgent.net/pay"),
    ("Su factura electronica vencio pague de inmediato para evitar multa", "http://factura-dian-pago.co-verify.ru/inv"),
    ("Netflix: su suscripcion fue cancelada actualice su metodo de pago", "http://netflix-pago-renovar.xyz/update"),
    ("Amazon: su pedido sera devuelto confirme su direccion ahora mismo", "http://amazon-pedido-confirmar.click/address"),
    ("WhatsApp: su cuenta expira hoy confirme para seguir usandola", "http://whatsapp-verificar-cuenta.info/confirm"),
    ("Instagram detected suspicious login verify your account immediately", "http://instagram-login-check.online/verify"),
    ("Su licencia de Microsoft Office expiro renuevela con descuento hoy", "http://microsoft-licencia-renovar.biz/offer"),
    ("Spotify: su metodo de pago fallo actualice para conservar Premium", "http://spotify-pago-actualizar.top/premium"),
    ("Claro: tiene una deuda pendiente evite el corte confirme sus datos", "http://claro-deuda-corte.ru/pagar"),

    # --- Phishing laboral y gubernamental ---
    ("Oferta de empleo gane dinero rapido envie sus datos bancarios ya", "http://trabajo-desde-casa-rapido.biz/apply@now"),
    ("Confirme su numero de seguridad social para evitar bloqueo", "http://gov-secure-verification.xyz/ssn"),
    ("Alerta su correo sera eliminado reactive su cuenta ahora", "http://email-reactivacion-soporte.com/keep"),
    ("Ha sido preseleccionado para empleo en empresa internacional aplique", "http://empleo-internacional-urgente.win/apply"),
    ("MinSalud: su carnet de vacunacion tiene inconsistencias corrijalas ya", "http://minsalud-carnet-verificar.top/corregir"),
    ("SENA: su certificado esta listo descargarlo antes de que expire hoy", "http://sena-certificado-descarga.xyz/obtener"),
    ("Ministerio de Hacienda: hay un error en su declaracion de renta", "http://hacienda-declaracion-error.click/corregir"),
    ("Rama Judicial: tiene una citacion pendiente confirme su asistencia", "http://ramajudicial-citacion.info/confirmar"),

    # --- Phishing sofisticado sin errores obvios ---
    ("Estimado cliente, hemos detectado acceso no autorizado a su cuenta. Por favor verifique su identidad.", "http://seguridad.banco-col.verify-id.com/auth"),
    ("Dear user, your account requires immediate attention. Please log in to resolve the issue.", "http://support.account-help-center.net/login"),
    ("Le informamos que su pago mensual no pudo procesarse. Actualice su informacion de facturacion.", "http://pagos.plataforma-segura.co.xyz/update"),
    ("Your subscription renewal failed. Click here to update your payment method and avoid interruption.", "http://renew.subscription-service.online/pay"),
    ("Hemos identificado un problema con su cuenta. Siga las instrucciones para protegerla.", "http://cuentas.verificacion-segura.biz/protect"),
]

_LEGIT = [
    # --- Correos corporativos y académicos ---
    ("Informe mensual de ventas adjunto para su revision", "https://drive.company.com/reports/ventas-marzo.pdf"),
    ("Acta de la reunion del comite academico de ayer", ""),
    ("Recordatorio entrega del proyecto de grado el viernes", "https://aulavirtual.universidadean.edu.co/curso/proyecto"),
    ("Hola equipo adjunto la agenda de la proxima semana", ""),
    ("Confirmacion de su cita medica para el martes a las diez", "https://citas.eps-sura.com.co/mi-cita"),
    ("Gracias por su compra aqui esta el resumen de su pedido", "https://www.tienda-oficial.com/pedido/12345"),
    ("Boletin de noticias de la universidad edicion de marzo", "https://universidadean.edu.co/noticias/marzo"),
    ("Actualizacion del cronograma del semestre 2026", ""),
    ("Resumen de la clase de redes y seguridad informatica", ""),
    ("Invitacion al seminario de inteligencia artificial aplicada", "https://eventos.universidadean.edu.co/seminario-ia"),
    ("Minuta de la reunion de seguimiento del sprint actual", "https://jira.company.com/sprint/42"),
    ("Adjunto el manual de usuario solicitado la semana pasada", "https://docs.company.com/manual-v2.pdf"),
    ("Felicitaciones por tu cumpleanos de parte de todo el equipo", ""),
    ("Confirmamos la recepcion de tu solicitud de vacaciones", "https://rrhh.company.com/solicitudes"),
    ("Aqui tienes el enlace al repositorio del proyecto en git", "https://github.com/usuario/fluxguard"),
    ("Reporte de avance del laboratorio de la materia de proyecto", ""),
    ("Tu pedido fue enviado puedes seguirlo con el numero de guia", "https://www.servientrega.com/seguimiento/9981"),
    ("Resumen de tu estado de cuenta del mes esta disponible", "https://www.bancolombia.com/personas/estado-cuenta"),
    ("Nueva actualizacion de la politica de privacidad de la plataforma", "https://www.plataforma.com/privacidad"),
    ("Te compartieron un documento de la materia de seguridad", "https://docs.google.com/document/d/abc123/edit"),
    # --- Notificaciones legítimas con palabras de urgencia (casos ambiguos) ---
    ("Recordatorio: el plazo de pago de matricula vence el viernes", "https://financiero.universidadean.edu.co/pagos"),
    ("Importante: actualiza tu contrasena antes del proximo mes por politica de seguridad", "https://sso.empresa.com/cambiar-clave"),
    ("Alerta de mantenimiento: el sistema estara inactivo el sabado de 2am a 4am", "https://status.empresa.com/mantenimiento"),
    ("Confirma tu asistencia al taller del jueves antes del miercoles", "https://eventos.empresa.com/taller-dev"),
    ("Tu contrato de trabajo esta listo para firma en DocuSign", "https://app.docusign.com/sign/contract-2026"),
    ("Verificacion de dos pasos activada en tu cuenta correctamente", "https://myaccount.google.com/security"),
    ("Su cita con el asesor financiero queda confirmada para el lunes", "https://agenda.empresa.com/citas/41"),
    ("El reporte de tu equipo fue aprobado y esta disponible en drive", "https://drive.google.com/file/d/xyz/view"),
    ("Aviso legal: cambios en los terminos del servicio entran en vigor en 30 dias", "https://legal.empresa.com/terminos-2026"),
    ("Tienes una nueva tarea asignada en el proyecto de ciberseguridad", "https://trello.com/b/abc/fluxguard"),
    # --- Notificaciones de sistemas conocidos ---
    ("GitHub: a new pull request was opened on fluxguard repository", "https://github.com/usuario/fluxguard/pull/12"),
    ("Slack: you have 3 unread messages in the security channel", "https://empresa.slack.com/channels/security"),
    ("Zoom: your meeting starts in 15 minutes click to join", "https://zoom.us/j/123456789"),
    ("Google Calendar: recordatorio tu reunion de proyecto es en una hora", "https://calendar.google.com/event/abc"),
    ("LinkedIn: tienes 5 nuevas solicitudes de conexion esta semana", "https://www.linkedin.com/mynetwork/"),
    ("Dropbox: el archivo compartido contigo esta listo para descargar", "https://www.dropbox.com/sh/abc123/file.pdf"),
    ("Notion: tu espacio de trabajo tiene actualizaciones pendientes", "https://www.notion.so/updates"),
    ("Trello: se te asigno una tarjeta en el tablero de proyecto final", "https://trello.com/c/abcdef"),
    ("YouTube: el video que guardaste ya esta disponible para ver", "https://www.youtube.com/watch?v=dQw4w9WgXcQ"),
    ("Figma: alguien comento en tu diseno de interfaz de fluxguard", "https://www.figma.com/file/abc/fluxguard"),
]

# Patrones léxicos de urgencia y coerción (ingeniería social)
# Esta expresión regular detecta palabras que los atacantes usan para presionar al usuario
_URGENCIA = re.compile(
    r"\b(urgent|urgente|inmediat|ahora|hoy|bloque|suspend|verifi|premio|gan[ae]|"
    r"reclam|confirm|expir|alerta|locked|password|contrasena|click|clic|vence|"
    r"corte|deuda|multa|cancelad|fraude|sospech|inusual|unauthorized|limited)\\w*",
    re.IGNORECASE,
)
_IP_EN_URL = re.compile(r"https?://\d{1,3}(?:\.\d{1,3}){3}")
_TLD_SOSPECHOSO = re.compile(r"\.(win|top|xyz|click|biz|info|online|ru|tk|pw|cc|ml)\b", re.IGNORECASE)


def extraer_features_url(texto: str, url: str) -> dict:
    """
    Extrae características estructurales interpretables de la URL y el texto.
    Estas features complementan el TF-IDF y son fáciles de explicar al jurado:
    cada una tiene una razón técnica clara.
    """
    combo = f"{texto} {url}"
    return {
        "url_len": len(url),
        "url_puntos": url.count("."),
        "url_guiones": url.count("-"),
        "url_tiene_ip": 1 if _IP_EN_URL.search(url) else 0,
        "url_tiene_arroba": 1 if "@" in url else 0,
        "url_https": 1 if url.startswith("https://") else 0,
        "url_tld_sospechoso": 1 if _TLD_SOSPECHOSO.search(url) else 0,
        "url_digitos": sum(c.isdigit() for c in url),
        "txt_palabras_urgencia": len(_URGENCIA.findall(combo)),
        "txt_signos_admiracion": combo.count("!"),
        "txt_longitud": len(texto),
    }


# Lista de columnas de features estructurales (se usa en engine.py y evaluate.py)
FEATURE_COLS = list(extraer_features_url("", "").keys())


def cargar_phishing() -> pd.DataFrame:
    """
    Construye el DataFrame con todos los correos etiquetados.
    Cada fila tiene: texto, url, label (1=phishing, 0=legítimo) + features.
    """
    filas = []
    for texto, url in _PHISHING:
        filas.append({"texto": texto, "url": url, "label": 1, **extraer_features_url(texto, url)})
    for texto, url in _LEGIT:
        filas.append({"texto": texto, "url": url, "label": 0, **extraer_features_url(texto, url)})
    return pd.DataFrame(filas)


# ==========================================================================
# 2. TRÁFICO DDoS — dataset etiquetado sintético con ruido realista
# ==========================================================================
# Las desviaciones son altas a propósito para que los datos se solapen
# y el modelo no aprenda algo demasiado fácil.
_PERFILES = {
    "normal":      {"label": 0, "pps": (600, 400),     "lat": (40, 35),   "bw": (15, 12),  "syn": (0.10, 0.10)},
    "volumetrico": {"label": 1, "pps": (35000, 18000),  "lat": (170, 80),  "bw": (120, 45), "syn": (0.15, 0.12)},
    "protocolo":   {"label": 1, "pps": (70000, 30000),  "lat": (130, 70),  "bw": (50, 25),  "syn": (0.70, 0.20)},
    "aplicacion":  {"label": 1, "pps": (1500, 900),     "lat": (430, 160), "bw": (25, 15),  "syn": (0.25, 0.15)},
}


def generar_trafico(n: int = 5000, seed: int = config.SEED, ruido: float = 0.03) -> pd.DataFrame:
    """
    Genera tráfico de red etiquetado. El parámetro `ruido` invierte una
    fracción de las etiquetas para simular errores de medición reales.
    Sin este ruido, los modelos darían 100% trivialmente.
    """
    rng = np.random.default_rng(seed)
    pesos = {"normal": 0.55, "volumetrico": 0.16, "protocolo": 0.16, "aplicacion": 0.13}
    filas = []
    for nombre, p in pesos.items():
        perfil = _PERFILES[nombre]
        m = int(n * p)
        pps = rng.normal(*perfil["pps"], m).clip(0)
        lat = rng.normal(*perfil["lat"], m).clip(1)
        bw  = rng.normal(*perfil["bw"],  m).clip(0)
        syn = rng.normal(*perfil["syn"], m).clip(0, 1)
        for i in range(m):
            filas.append({
                "pps": float(pps[i]), "latencia_ms": float(lat[i]),
                "ancho_banda_mbps": float(bw[i]), "syn_ratio": float(syn[i]),
                "label": perfil["label"],
            })
    df = pd.DataFrame(filas).sample(frac=1, random_state=seed).reset_index(drop=True)
    # Agrego ruido: invierto etiquetas en una pequeña fracción de muestras
    n_flip = int(len(df) * ruido)
    flip_idx = rng.choice(df.index, size=n_flip, replace=False)
    df.loc[flip_idx, "label"] = 1 - df.loc[flip_idx, "label"]
    return df


DDOS_FEATURES = ["pps", "latencia_ms", "ancho_banda_mbps", "syn_ratio"]


def cargar_ddos() -> tuple:
    """
    Devuelve (DataFrame, fuente). Si existe el CSV real de CICDDoS2019,
    lo usa; si no, genera el benchmark sintético reproducible.
    """
    import os
    if os.path.exists(config.CICDDOS_CSV):
        df = pd.read_csv(config.CICDDOS_CSV)
        return df, "CICDDoS2019 (real)"
    return generar_trafico(), "benchmark sintético"
