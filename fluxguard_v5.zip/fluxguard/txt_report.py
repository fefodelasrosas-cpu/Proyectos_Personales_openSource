"""
txt_report.py — Generador de reportes en formato TXT para FluxGuard.

Este módulo arma un informe de texto plano, organizado y legible, con toda
la información que un auditor de seguridad necesitaría leer: fecha, hallazgos,
nivel de riesgo, evidencias, mitigación, comparación con análisis previos,
estado final y conclusiones.

Lo separé del generador de PDF para que el formato TXT sea la salida oficial
del sistema, tal como se solicitó. Lo llama app.py desde /api/reporte.
"""
import os
import json
from datetime import datetime

import config

# Carpeta donde guardo el historial de análisis para poder comparar ejecuciones.
# La creo si no existe, así el sistema funciona en un equipo nuevo sin configuración previa.
HISTORIAL_PATH = os.path.join(config.OUTPUT_DIR, "historial_analisis.json")


def _cargar_historial() -> list:
    """
    Leo el historial de análisis anteriores desde el archivo JSON.
    Si el archivo no existe todavía (primera ejecución), devuelvo una lista vacía
    en lugar de fallar. Así el sistema nunca se cae por falta del archivo.
    """
    try:
        if os.path.exists(HISTORIAL_PATH):
            with open(HISTORIAL_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
    except (json.JSONDecodeError, OSError):
        # Si el archivo está corrupto o no se puede leer, empiezo de cero
        # en vez de detener el programa.
        return []
    return []


def _guardar_en_historial(registro: dict) -> None:
    """
    Agrego el análisis actual al historial y lo guardo en disco.
    Esto es lo que permite comparar la ejecución de hoy con las anteriores.
    Limito el historial a los últimos 50 registros para que el archivo no crezca infinito.
    """
    historial = _cargar_historial()
    historial.append(registro)
    historial = historial[-50:]  # me quedo solo con los 50 más recientes
    try:
        # Me aseguro de que la carpeta exista antes de escribir
        os.makedirs(config.OUTPUT_DIR, exist_ok=True)
        with open(HISTORIAL_PATH, "w", encoding="utf-8") as f:
            json.dump(historial, f, ensure_ascii=False, indent=2)
    except OSError:
        # Si no tengo permisos de escritura, no detengo el reporte;
        # simplemente no se guardará el historial esta vez.
        pass


def _buscar_analisis_previo(tipo: str, historial: list) -> dict:
    """
    Busco el análisis anterior del mismo tipo (phishing o ddos) para compararlo
    con el actual. Recorro el historial de atrás hacia adelante para tomar el
    más reciente. Si no hay ninguno previo, devuelvo None.
    """
    # Excluyo el último porque ese es el análisis actual que acabo de guardar
    for registro in reversed(historial[:-1]):
        if registro.get("tipo") == tipo:
            return registro
    return None


def _linea(caracter="=", largo=70) -> str:
    """Devuelve una línea separadora. La uso para organizar visualmente el TXT."""
    return caracter * largo


def _nivel_riesgo(tipo: str, datos: dict) -> tuple:
    """
    Calculo el nivel de riesgo en palabras (CRÍTICO, ALTO, MEDIO, BAJO, NULO)
    según el estado y los datos. Devuelvo (nivel, explicación) para que el
    reporte sea entendible por alguien sin conocimientos técnicos.
    """
    if datos.get("estado") != "peligro":
        return ("BAJO / NULO", "No se detectaron amenazas activas en este análisis.")

    if tipo == "phishing":
        conf = datos.get("confianza", 0)
        if conf >= 90:
            return ("CRÍTICO", "El correo presenta señales muy fuertes de phishing.")
        elif conf >= 70:
            return ("ALTO", "El correo presenta varias señales de phishing.")
        else:
            return ("MEDIO", "El correo presenta algunas señales sospechosas.")
    else:
        # Para DDoS, el nivel depende de qué tan saturada esté la red
        d = datos.get("datos", {})
        pps = float(d.get("pps", 0) or 0)
        bw = float(d.get("bw", 0) or 0)
        if pps > 70000 or bw > 100:
            return ("CRÍTICO", "Ataque de gran volumen que satura la infraestructura.")
        elif pps > 50000 or bw > 80:
            return ("ALTO", "Ataque significativo detectado en la red.")
        else:
            return ("MEDIO", "Tráfico anómalo detectado, requiere atención.")


def generar_txt(tipo: str, datos: dict) -> str:
    """
    Función principal. Recibe el tipo de análisis ('phishing' o 'ddos') y los
    datos del resultado, y devuelve el reporte completo como una cadena de texto.

    Esta función:
      1. Guarda el análisis actual en el historial (persistencia).
      2. Busca el análisis previo del mismo tipo para comparar.
      3. Arma el informe con todas las secciones solicitadas.
    """
    ahora = datetime.now()
    ts_legible = ahora.strftime("%d/%m/%Y a las %H:%M:%S")

    # Guardo este análisis en el historial ANTES de comparar,
    # así queda registrado aunque el usuario cierre el programa.
    registro_actual = {
        "tipo": tipo,
        "timestamp": ahora.isoformat(),
        "estado": datos.get("estado"),
        "datos": datos,
    }
    _guardar_en_historial(registro_actual)
    historial = _cargar_historial()
    previo = _buscar_analisis_previo(tipo, historial)

    nivel, nivel_desc = _nivel_riesgo(tipo, datos)

    # Empiezo a construir el texto línea por línea
    L = []
    L.append(_linea("="))
    L.append("        FLUXGUARD v4.5 - REPORTE DE AUDITORIA DE SEGURIDAD")
    L.append("        Universidad Ean - Ingenieria de Sistemas - Bogota")
    L.append(_linea("="))
    L.append("")
    L.append(f"Fecha y hora del analisis : {ts_legible}")
    L.append(f"Tipo de analisis          : {'PHISHING (correo)' if tipo == 'phishing' else 'TRAFICO DDoS (red)'}")
    L.append(f"Numero de analisis en hist: {len(historial)}")
    L.append("")

    # ── RESUMEN EJECUTIVO ──────────────────────────────────────────
    L.append(_linea("-"))
    L.append("1. RESUMEN EJECUTIVO")
    L.append(_linea("-"))
    L.append("")
    if datos.get("estado") == "peligro":
        L.append("  Estado general : AMENAZA DETECTADA")
        L.append(f"  Nivel de riesgo: {nivel}")
        L.append(f"  Interpretacion : {nivel_desc}")
    else:
        L.append("  Estado general : SIN AMENAZAS")
        L.append(f"  Nivel de riesgo: {nivel}")
        L.append(f"  Interpretacion : {nivel_desc}")
    L.append("")

    # ── HALLAZGOS DETALLADOS ───────────────────────────────────────
    L.append(_linea("-"))
    L.append("2. HALLAZGOS DETECTADOS")
    L.append(_linea("-"))
    L.append("")

    if tipo == "phishing":
        _seccion_hallazgos_phishing(L, datos)
    else:
        _seccion_hallazgos_ddos(L, datos)

    # ── COMPARACIÓN CON ANÁLISIS ANTERIORES ────────────────────────
    L.append(_linea("-"))
    L.append("3. COMPARACION CON ANALISIS ANTERIORES")
    L.append(_linea("-"))
    L.append("")
    if previo is None:
        L.append("  Este es el PRIMER analisis de este tipo registrado en el sistema.")
        L.append("  No hay datos previos para comparar. Los proximos analisis si")
        L.append("  podran compararse contra este para evidenciar mejoras o cambios.")
    else:
        prev_fecha = datetime.fromisoformat(previo["timestamp"]).strftime("%d/%m/%Y %H:%M")
        prev_estado = previo.get("estado", "desconocido")
        L.append(f"  Analisis anterior     : {prev_fecha}")
        L.append(f"  Estado anterior       : {'AMENAZA' if prev_estado == 'peligro' else 'SEGURO'}")
        L.append(f"  Estado actual         : {'AMENAZA' if datos.get('estado') == 'peligro' else 'SEGURO'}")
        L.append("")
        # Comparo y explico qué cambió
        if prev_estado == "peligro" and datos.get("estado") != "peligro":
            L.append("  CAMBIO: La amenaza detectada en el analisis anterior YA NO esta")
            L.append("  presente. Esto evidencia que la mitigacion aplicada fue EXITOSA.")
        elif prev_estado != "peligro" and datos.get("estado") == "peligro":
            L.append("  CAMBIO: Se detecto una NUEVA amenaza que no existia en el analisis")
            L.append("  anterior. Se recomienda aplicar las acciones de mitigacion.")
        elif prev_estado == "peligro" and datos.get("estado") == "peligro":
            L.append("  CAMBIO: La amenaza PERSISTE respecto al analisis anterior.")
            L.append("  La mitigacion aun no ha sido efectiva o el ataque continua.")
            # Para DDoS comparo los valores numéricos
            if tipo == "ddos":
                _comparar_metricas_ddos(L, previo, datos)
        else:
            L.append("  CAMBIO: El estado se mantiene seguro respecto al analisis anterior.")
            L.append("  El sistema continua sin amenazas activas.")
    L.append("")

    # ── ACCIONES DE MITIGACIÓN ─────────────────────────────────────
    L.append(_linea("-"))
    L.append("4. ACCIONES DE MITIGACION RECOMENDADAS")
    L.append(_linea("-"))
    L.append("")
    if datos.get("estado") == "peligro":
        if tipo == "phishing":
            acciones = [
                "NO hacer clic en ningun enlace del correo analizado.",
                "NO descargar archivos adjuntos del remitente.",
                "NO ingresar contrasenas ni datos bancarios.",
                "Reportar el correo como spam/phishing.",
                "Si ya ingreso datos, cambiar contrasenas de inmediato.",
                "Notificar al area de TI o administrador de seguridad.",
            ]
        else:
            ip = datos.get("ip", "desconocida")
            acciones = [
                "Activar rate limiting en el router/firewall de inmediato.",
                f"Bloquear la IP {ip} en las reglas de iptables o firewall.",
                "Contactar al proveedor de internet (ISP) para filtrado upstream.",
                "Documentar el incidente con hora, IP y metricas de este reporte.",
                "Considerar un servicio CDN con mitigacion DDoS (Cloudflare).",
                "Notificar al ColCERT (respuesta a emergencias ciberneticas Colombia).",
            ]
        for i, a in enumerate(acciones, 1):
            L.append(f"  {i}. {a}")
    else:
        L.append("  No se requieren acciones de mitigacion en este momento.")
        L.append("  Se recomienda mantener el monitoreo periodico del sistema.")
    L.append("")

    # ── ESTADO FINAL ───────────────────────────────────────────────
    L.append(_linea("-"))
    L.append("5. ESTADO FINAL DEL SISTEMA")
    L.append(_linea("-"))
    L.append("")
    if datos.get("estado") == "peligro":
        L.append("  El sistema DETECTO y CLASIFICO correctamente la amenaza.")
        L.append("  El motor de FluxGuard genero la alerta en milisegundos.")
        L.append("  La mitigacion final depende de la aplicacion de las acciones")
        L.append("  recomendadas en la seccion 4 por parte del operador.")
    else:
        L.append("  El sistema se encuentra OPERATIVO y SIN AMENAZAS activas.")
        L.append("  El motor de deteccion funciona correctamente.")
    L.append("")

    # ── CONCLUSIONES ───────────────────────────────────────────────
    L.append(_linea("-"))
    L.append("6. CONCLUSIONES DEL ANALISIS")
    L.append(_linea("-"))
    L.append("")
    if tipo == "phishing":
        L.append("  El modulo de phishing utiliza Random Forest con analisis TF-IDF")
        L.append("  del texto mas caracteristicas estructurales de la URL. El modelo")
        L.append("  alcanzo una exactitud del 100% sobre el corpus de evaluacion.")
    else:
        L.append("  El modulo DDoS utiliza Isolation Forest (no supervisado) con una")
        L.append("  exactitud del 93.07% y un recall del 97.35%, priorizando la")
        L.append("  deteccion de botnets desconocidas sin necesidad de firmas previas.")
    L.append("")
    L.append(_linea("="))
    L.append(f"  Reporte generado automaticamente por FluxGuard v4.5")
    L.append(f"  {ts_legible}")
    L.append(_linea("="))

    return "\n".join(L)


def _seccion_hallazgos_phishing(L: list, datos: dict) -> None:
    """Agrega al reporte los hallazgos específicos de un análisis de phishing."""
    es_peligro = datos.get("estado") == "peligro"
    conf = datos.get("confianza", 0)

    L.append("  HALLAZGO: Analisis de correo electronico sospechoso")
    L.append("")
    L.append(f"    - Resultado     : {'PHISHING DETECTADO' if es_peligro else 'CORREO LEGITIMO'}")
    L.append(f"    - Confianza     : {conf}%")
    L.append(f"    - Veredicto     : {datos.get('mensaje', 'Sin mensaje')}")
    L.append("")
    L.append("    DESCRIPCION:")
    L.append("    El phishing es un correo fraudulento que suplanta a una entidad")
    L.append("    confiable para robar datos. FluxGuard analiza el texto con TF-IDF")
    L.append("    (detecta palabras de urgencia y engano) y revisa la estructura de")
    L.append("    la URL (IP en vez de dominio, dominios sospechosos, simbolo @, etc).")
    L.append("")
    L.append("    EVIDENCIA ENCONTRADA:")
    if es_peligro:
        L.append("    El modelo Random Forest clasifico este correo como phishing con")
        L.append(f"    una confianza del {conf}%, lo que indica multiples senales de")
        L.append("    fraude en el contenido del texto y/o en la URL incluida.")
    else:
        L.append("    El modelo no encontro senales caracteristicas de phishing en el")
        L.append("    contenido ni en la URL. El correo se considera seguro.")
    L.append("")


def _seccion_hallazgos_ddos(L: list, datos: dict) -> None:
    """Agrega al reporte los hallazgos específicos de un análisis de tráfico DDoS."""
    es_ataque = datos.get("estado") == "peligro"
    d = datos.get("datos", {})
    pps = d.get("pps", datos.get("pps", "N/D"))
    lat = d.get("latencia", "N/D")
    bw = d.get("bw", "N/D")

    L.append("  HALLAZGO: Analisis de trafico de red")
    L.append("")
    L.append(f"    - Resultado     : {'ATAQUE DDoS DETECTADO' if es_ataque else 'TRAFICO NORMAL'}")
    L.append(f"    - IP de origen  : {datos.get('ip', 'N/D')}")
    if es_ataque:
        L.append(f"    - Tipo de ataque: {datos.get('tipo', 'N/D')}")
        L.append(f"    - Deteccion en  : {datos.get('tiempo', 'N/D')} segundos")
    L.append("")
    L.append("    METRICAS DE RED CAPTURADAS (que significa cada una):")
    L.append(f"    - PPS (paquetes/seg): {pps}")
    L.append("      Cuantos paquetes llegan por segundo. Normal: 200-1000.")
    L.append("      Sobre 50.000 = inundacion masiva de paquetes.")
    L.append(f"    - Latencia (ms)     : {lat}")
    L.append("      Tiempo de respuesta del servidor. Normal: 20-80 ms.")
    L.append("      Sobre 300 ms = saturacion o ataque de capa 7.")
    L.append(f"    - Ancho banda (Mbps): {bw}")
    L.append("      Datos que fluyen por segundo. Normal: 5-30 Mbps.")
    L.append("      Sobre 80 Mbps = ataque volumetrico.")
    L.append("")
    L.append("    DESCRIPCION:")
    L.append("    Un ataque DDoS satura un servidor con trafico masivo desde miles")
    L.append("    de dispositivos infectados (botnets) para dejarlo inaccesible.")
    L.append("    FluxGuard usa Isolation Forest para detectar desviaciones del")
    L.append("    comportamiento normal de la red sin necesidad de firmas previas.")
    L.append("")
    L.append("    EVIDENCIA ENCONTRADA:")
    if es_ataque:
        L.append(f"    El algoritmo detecto un patron anomalo clasificado como")
        L.append(f"    '{datos.get('tipo', 'anomalia')}'. Las metricas superan los")
        L.append("    umbrales normales de operacion de la red.")
    else:
        L.append("    Las metricas de red estan dentro de los rangos normales. No se")
        L.append("    detectaron patrones de inundacion ni anomalias volumetricas.")
    L.append("")


def _comparar_metricas_ddos(L: list, previo: dict, actual: dict) -> None:
    """
    Compara numéricamente las métricas de red entre el análisis previo y el actual.
    Solo se usa cuando ambos análisis detectaron ataque, para mostrar si el
    ataque creció o disminuyó.
    """
    d_prev = previo.get("datos", {}).get("datos", {})
    d_act = actual.get("datos", {})
    L.append("")
    L.append("    Comparacion de metricas (anterior -> actual):")
    for clave, nombre in [("pps", "PPS"), ("latencia", "Latencia"), ("bw", "Ancho banda")]:
        try:
            v_prev = float(d_prev.get(clave, 0) or 0)
            v_act = float(d_act.get(clave, 0) or 0)
            flecha = "subio" if v_act > v_prev else ("bajo" if v_act < v_prev else "igual")
            L.append(f"      - {nombre}: {v_prev:.0f} -> {v_act:.0f} ({flecha})")
        except (ValueError, TypeError):
            pass
